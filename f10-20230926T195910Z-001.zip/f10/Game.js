



const config={
    type:Phaser.AUTO,
    width:800,
    height:700,
    backgroundColor:"0x000000",
    scene:[Scene1,Scene2,],
    pixelArt:true,
    physics: {
      default: "arcade",
      arcade:{
        debug:false
      }


    }
  }

 let gameSettings={
   playerSpeed:200, 
 }
 
window.onload=function(){

  var game=new Phaser.Game(config);

}

/*
INIT()
PRELOAD()
CREATE()
UPDATE()
*/
