 class Scene2 extends Phaser.Scene{

    constructor(){ 

         super("PlayGame");

    }
    

    
   
   create(){
        //this.background=this.add.image(0,0,"background");
        //this.background.setOrigin(0,0);
        this.b=this.add.image(0,0,"b");
        this.b.setOrigin(0,0);
        
        this.s1=this.add.sprite(config.width/2-200,config.height/2,"s1");
        this.s2=this.add.sprite(config.width/2,config.height/2,"s2");
        this.s3=this.add.sprite(config.width/2+200,config.height/2,"s3");
        //this.s1.setScale(4);
        this.anims.create({
            key:"ship1_anim",
            frames:this.anims.generateFrameNumbers("s1"),
            frameRate:20,
            repeat:-1
        })

        this.anims.create({
            key:"ship2_anim",
            frames:this.anims.generateFrameNumbers("s2"),
            frameRate:20,
            repeat:-1
        })

        this.anims.create({
            key:"ship3_anim",
            frames:this.anims.generateFrameNumbers("s3"),
            frameRate:20,
            repeat:-1
        })
        
        this.j=this.add.sprite(config.width/2-8,config.height-64,"j");
        this.cursorKeys=this.input.keyboard.createCursorKeys();
        /*this.s1.play("ship1_anim");
        this.s2.play("ship2_anim");
        this.s3.play("ship3_anim");
        */
        /*this.s1.setInteractive();
        this.s2.setInteractive();
        this.s3.setInteractive();*/
        //this.load.image("denk","estrada.jpg");
        this.add.text(20,20,"Playing game",
        {font:"25px Arial",
        fill:"yellow"
    });
     // cursors=this.input.keyboard.createCursorKeys();
    }

    update(){
         this.moveShip(this.s1,2.5);
         this.moveShip(this.s2,2);
         this.moveShip(this.s3,3);
         this.moverJogador(); 
        
    }
    
    moverJogador(){
        if(this.cursorKeys.right.isDown){
            this.j.x += 6;
        }
        
        if(this.cursorKeys.left.isDown){
           this.j.x -= 6;
        }
       
        if(this.cursorKeys.up.isDown){
            this.j.y += 6;
        }


        if(this.cursorKeys.down.isDown){
            this.j.y -= 6;
        }
        
    }

    moveShip(ship,speed){
        ship.y+=speed;
        if (ship.y>config.height){
            this.resetShipPos(ship);
        }
    }

    resetShipPos(ship){
        ship.y=0;
        var randomX=Phaser.Math.Between(0,config.width);
        ship.x=randomX;


    }
}
