 class Scene1 extends Phaser.Scene{

   constructor(){

     super("bootGame");

   }
   
    
    preload(){
        //this.load.image("denki","boneco.jpg",{frameWidth:16,frameHeight:16});
        this.load.spritesheet("s1","p3.jpg",
        {
          frameWidth:150,
          frameHeight:150
        });

        this.load.spritesheet("s2","p3.jpg",{
          frameWidth:130,
          frameHeight:130
        });
        this.load.spritesheet("s3","p3.jpg",{
          frameWidth:250,
          frameHeight:230
        });
        this.load.image("b","fundo.png")
        console.log('Essa porcaria sempre acontece');
        //this.preload.color("blue")

        this.load.spritesheet("j","p2.jpg",{frameWidth:160,frameHeight:240}); 
    }
    
   create(){

       this.add.text(20,20,"Loading game...");
       this.scene.start("PlayGame");

   }
} 